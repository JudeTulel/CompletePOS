import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Sale } from './sales.entity';
import { SalesDetailsService } from './sales-details/sales-details.service';

@Injectable()
export class SalesService {
    constructor(
        @InjectRepository(Sale)
        private readonly saleRepository: Repository<Sale>,
        private readonly salesDetailsService: SalesDetailsService,
    ) {}

    async createSale(totalAmount: number): Promise<Sale> {
        const sale = this.saleRepository.create({ totalAmount });
        return this.saleRepository.save(sale);
    }

    async findAll(): Promise<Sale[]> {
        return this.saleRepository.find();
    }

    async findOne(saleId: number): Promise<Sale | null> {
        return this.saleRepository.findOneBy({ saleId });
    }

    async create(data: any) {
        // Create the sale
        const sale = this.saleRepository.create(data);
        const savedSale = await this.saleRepository.save(sale);
        // After saving the sale, get all sale details for this sale and decrement stock
        const saleDetails = await this.salesDetailsService.findAll();
        for (const detail of saleDetails) {
            if (detail.sale && detail.sale.saleId === savedSale.saleId && detail.product && detail.quantity) {
                await this.salesDetailsService.productsService.adjustStock(detail.product.id, { quantity: -detail.quantity, reason: 'sale' });
            }
        }
        return savedSale;
    }

    async createDetail(data: any) {
        // Implement your sales detail creation logic here
        // Example: create a new sales detail record
        // You may need to inject the repository for sales details
        return { message: 'Sales detail created (implement logic)' };
    }
}
