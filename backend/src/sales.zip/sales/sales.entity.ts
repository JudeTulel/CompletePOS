import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, OneToMany } from 'typeorm';
import { SalesDetail } from './sales-details/sales-details.entity';

@Entity('Sales')
export class Sale {
    @PrimaryGeneratedColumn({ name: 'SaleID' })
    saleId: number;

    @CreateDateColumn({ name: 'SaleDate', type: 'timestamp',})
    saleDate: Date;


    @Column('decimal', { name: 'TotalAmount', precision: 10, scale: 2 })
    totalAmount: number;

    @Column({ type: 'enum', enum: ['cash', 'mpesa', 'hybrid'], default: 'cash' })
    paymentMethod: string;


    @Column({ nullable: true })
    cashierId: number;

    @OneToMany(() => SalesDetail, detail => detail.sale)
    details: SalesDetail[];

    @CreateDateColumn()
    createdAt: Date;
}