import { Controller, Get, Post, Body } from '@nestjs/common';
import { SalesService } from './sales.service';
@Controller('sales')
export class SalesController {
    constructor(private readonly salesService: SalesService) {}
    
    @Get()
    async getSales() {
        return this.salesService.findAll();
    }
    
    @Get('sale:id')
    async getSale(id: number) {
        return this.salesService.findOne(id);
    }
    
    @Post()
    async create(@Body() data: any) {
        return this.salesService.create(data);
    }

    @Post('details')
    async createDetail(@Body() data: any) {
        return this.salesService.createDetail(data);
    }
}
